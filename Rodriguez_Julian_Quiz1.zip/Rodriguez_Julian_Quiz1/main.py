##function for width and height


def calc_area(w , h):
    calc_area(w * h)

area = calc_area(10 * 10)

if area=1000000000:
    print "The squeare has an area of" +area+ "."
elif area=40:
    print "The rectangle has an area of" +area+ "."




##Bottles on the wall
# def count_down():
#     bottles = 99
#
#     for i in range(0, bottles):

